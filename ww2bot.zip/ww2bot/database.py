import sqlite3
import json
from typing import Optional, List, Dict

DB_PATH = "ww2bot.db"

class Database:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._create_tables()

    def _create_tables(self):
        c = self.conn.cursor()
        c.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                user_id     INTEGER PRIMARY KEY,
                username    TEXT,
                is_admin    INTEGER DEFAULT 0,
                vip_approved INTEGER DEFAULT 0,
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS players (
                user_id     INTEGER PRIMARY KEY,
                country     TEXT,
                budget      INTEGER DEFAULT 0,
                daily_income INTEGER DEFAULT 0,
                satisfaction INTEGER DEFAULT 0,
                FOREIGN KEY(user_id) REFERENCES users(user_id)
            );

            CREATE TABLE IF NOT EXISTS infrastructure (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER,
                item_id     TEXT,
                count       INTEGER DEFAULT 1,
                UNIQUE(user_id, item_id)
            );

            CREATE TABLE IF NOT EXISTS military (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER,
                item_id     TEXT,
                count       INTEGER DEFAULT 0,
                UNIQUE(user_id, item_id)
            );

            CREATE TABLE IF NOT EXISTS infantry (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER,
                item_id     TEXT,
                count       INTEGER DEFAULT 0,
                UNIQUE(user_id, item_id)
            );

            CREATE TABLE IF NOT EXISTS admins (
                user_id     INTEGER PRIMARY KEY
            );
        """)
        self.conn.commit()

    # ── Users ──────────────────────────────────────
    def add_user(self, user_id: int, username: str):
        self.conn.execute(
            "INSERT OR IGNORE INTO users (user_id, username) VALUES (?, ?)",
            (user_id, username)
        )
        self.conn.execute(
            "INSERT OR IGNORE INTO players (user_id, budget) VALUES (?, 0)",
            (user_id,)
        )
        self.conn.commit()

    def get_player(self, user_id: int) -> Optional[Dict]:
        row = self.conn.execute(
            """SELECT u.user_id, u.username, u.vip_approved,
                      p.country, p.budget, p.daily_income, p.satisfaction
               FROM users u JOIN players p ON u.user_id=p.user_id
               WHERE u.user_id=?""",
            (user_id,)
        ).fetchone()
        return dict(row) if row else None

    def set_vip_approved(self, user_id: int, approved: bool):
        self.conn.execute(
            "UPDATE users SET vip_approved=? WHERE user_id=?",
            (1 if approved else 0, user_id)
        )
        self.conn.commit()

    def is_vip_approved(self, user_id: int) -> bool:
        row = self.conn.execute(
            "SELECT vip_approved FROM users WHERE user_id=?", (user_id,)
        ).fetchone()
        return bool(row and row["vip_approved"])

    # ── Country ─────────────────────────────────────
    def set_player_country(self, user_id: int, country: str, budget: int):
        self.conn.execute(
            "UPDATE players SET country=?, budget=? WHERE user_id=?",
            (country, budget, user_id)
        )
        self.conn.commit()

    def get_taken_countries(self) -> List[str]:
        rows = self.conn.execute(
            "SELECT country FROM players WHERE country IS NOT NULL"
        ).fetchall()
        return [r["country"] for r in rows]

    # ── Budget ──────────────────────────────────────
    def update_budget(self, user_id: int, new_budget: int):
        self.conn.execute(
            "UPDATE players SET budget=? WHERE user_id=?",
            (new_budget, user_id)
        )
        self.conn.commit()

    def transfer_money(self, from_id: int, to_id: int, amount: int):
        p_from = self.get_player(from_id)
        p_to = self.get_player(to_id)
        self.conn.execute(
            "UPDATE players SET budget=? WHERE user_id=?",
            (p_from["budget"] - amount, from_id)
        )
        self.conn.execute(
            "UPDATE players SET budget=? WHERE user_id=?",
            (min(p_to["budget"] + amount, 500_000_000), to_id)
        )
        self.conn.commit()

    # ── Infrastructure ──────────────────────────────
    def get_infra_count(self, user_id: int, item_id: str) -> int:
        row = self.conn.execute(
            "SELECT count FROM infrastructure WHERE user_id=? AND item_id=?",
            (user_id, item_id)
        ).fetchone()
        return row["count"] if row else 0

    def buy_infra(self, user_id: int, item_id: str, cost: int, income: int, satisfaction: int):
        self.conn.execute(
            """INSERT INTO infrastructure (user_id, item_id, count) VALUES (?, ?, 1)
               ON CONFLICT(user_id, item_id) DO UPDATE SET count=count+1""",
            (user_id, item_id)
        )
        self.conn.execute(
            """UPDATE players
               SET budget=budget-?,
                   daily_income=MIN(daily_income+?, 500000000),
                   satisfaction=MIN(satisfaction+?, 100)
               WHERE user_id=?""",
            (cost, income, satisfaction, user_id)
        )
        self.conn.commit()

    # ── Military equipment ──────────────────────────
    def get_equip_count(self, user_id: int, item_id: str) -> int:
        row = self.conn.execute(
            "SELECT count FROM military WHERE user_id=? AND item_id=?",
            (user_id, item_id)
        ).fetchone()
        return row["count"] if row else 0

    def buy_equipment(self, user_id: int, item_id: str, cost: int):
        self.conn.execute(
            """INSERT INTO military (user_id, item_id, count) VALUES (?, ?, 1)
               ON CONFLICT(user_id, item_id) DO UPDATE SET count=count+1""",
            (user_id, item_id)
        )
        self.conn.execute(
            "UPDATE players SET budget=budget-? WHERE user_id=?",
            (cost, user_id)
        )
        self.conn.commit()

    def transfer_equipment(self, from_id: int, to_id: int, item_id: str, amount: int):
        self.conn.execute(
            "UPDATE military SET count=count-? WHERE user_id=? AND item_id=?",
            (amount, from_id, item_id)
        )
        self.conn.execute(
            """INSERT INTO military (user_id, item_id, count) VALUES (?, ?, ?)
               ON CONFLICT(user_id, item_id) DO UPDATE SET count=count+?""",
            (to_id, item_id, amount, amount)
        )
        self.conn.commit()

    # ── Infantry ────────────────────────────────────
    def get_infantry_count(self, user_id: int, item_id: str) -> int:
        row = self.conn.execute(
            "SELECT count FROM infantry WHERE user_id=? AND item_id=?",
            (user_id, item_id)
        ).fetchone()
        return row["count"] if row else 0

    def buy_infantry(self, user_id: int, item_id: str, cost: int):
        self.conn.execute(
            """INSERT INTO infantry (user_id, item_id, count) VALUES (?, ?, 1)
               ON CONFLICT(user_id, item_id) DO UPDATE SET count=count+1""",
            (user_id, item_id)
        )
        self.conn.execute(
            "UPDATE players SET budget=budget-? WHERE user_id=?",
            (cost, user_id)
        )
        self.conn.commit()

    # ── Full inventory ──────────────────────────────
    def get_full_inventory(self, user_id: int) -> Dict:
        result = {}
        from data import INFRASTRUCTURE, EQUIPMENT, INFANTRY, MISSILES, AIR_DEFENSE

        for item_id, item in INFRASTRUCTURE.items():
            count = self.get_infra_count(user_id, item_id)
            if count > 0:
                result[item["name"]] = count

        for item_id, item in {**EQUIPMENT, **MISSILES, **AIR_DEFENSE}.items():
            count = self.get_equip_count(user_id, item_id)
            if count > 0:
                result[item["name"]] = count

        for item_id, item in INFANTRY.items():
            count = self.get_infantry_count(user_id, item_id)
            if count > 0:
                result[item["name"]] = count

        return result

    # ── Admin ───────────────────────────────────────
    def is_admin(self, user_id: int) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM admins WHERE user_id=?", (user_id,)
        ).fetchone()
        return bool(row)

    def add_admin(self, user_id: int):
        self.conn.execute(
            "INSERT OR IGNORE INTO admins (user_id) VALUES (?)", (user_id,)
        )
        self.conn.commit()

    def admin_gift_equip(self, user_id: int, item_id: str, amount: int):
        self.conn.execute(
            """INSERT INTO military (user_id, item_id, count) VALUES (?, ?, ?)
               ON CONFLICT(user_id, item_id) DO UPDATE SET count=count+?""",
            (user_id, item_id, amount, amount)
        )
        self.conn.commit()

    def admin_gift_money(self, user_id: int, amount: int):
        self.conn.execute(
            "UPDATE players SET budget=MIN(budget+?, 500000000) WHERE user_id=?",
            (amount, user_id)
        )
        self.conn.commit()

    # ── Season reset ────────────────────────────────
    def reset_season(self):
        self.conn.executescript("""
            UPDATE players SET country=NULL, budget=0, daily_income=0, satisfaction=0;
            DELETE FROM infrastructure;
            DELETE FROM military;
            DELETE FROM infantry;
        """)
        self.conn.commit()

    # ── All players ─────────────────────────────────
    def get_all_players(self) -> List[Dict]:
        rows = self.conn.execute(
            """SELECT u.user_id, u.username, p.country, p.budget, p.daily_income
               FROM users u JOIN players p ON u.user_id=p.user_id
               WHERE p.country IS NOT NULL"""
        ).fetchall()
        return [dict(r) for r in rows]
