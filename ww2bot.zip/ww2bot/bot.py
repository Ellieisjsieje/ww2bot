import logging
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from database import Database
from data import COUNTRIES, EQUIPMENT, INFANTRY, get_equipment_by_id
from config import BOT_TOKEN, ADMIN_IDS

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

db = Database()

# ─────────────────────────────────────────────
#  /start
# ─────────────────────────────────────────────
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.add_user(user.id, user.username or user.first_name)

    channel_text = (
        "🌍 *به بازی جنگ جهانی دوم خوش آمدید!*\n\n"
        "📢 *ابتدا در کانال‌های ما عضو شوید:*\n"
        "• @your\_channel\_1\n"
        "• @your\_channel\_2\n\n"
        "بعد از عضویت دکمه زیر را بزنید 👇"
    )
    kb = [[InlineKeyboardButton("✅ عضو شدم، ادامه بده", callback_data="joined")]]
    await update.message.reply_text(channel_text, parse_mode="Markdown",
                                    reply_markup=InlineKeyboardMarkup(kb))

async def joined_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await show_country_list(query)

# ─────────────────────────────────────────────
#  نمایش لیست کشورها
# ─────────────────────────────────────────────
async def show_country_list(query):
    user_id = query.from_user.id
    player = db.get_player(user_id)
    taken = db.get_taken_countries()

    allies_text = "🟢 *Allies (متفقین):*\n"
    axis_text = "\n🔴 *Axis (محور):*\n"
    neutral_text = "\n⚪ *Neutral (بی‌طرف):*\n"
    occupied_text = "\n🟡 *Occupied (اشغال‌شده):*\n"

    for code, info in COUNTRIES.items():
        vip_mark = "💯" if info["vip"] else ""
        status = "🔒" if code in taken else "✅"
        line = f"{info['flag']} {info['name_fa']} {vip_mark} {status}\n"
        faction = info["faction"]
        if faction == "allies":
            allies_text += line
        elif faction == "axis":
            axis_text += line
        elif faction == "neutral":
            neutral_text += line
        else:
            occupied_text += line

    text = allies_text + axis_text + neutral_text + occupied_text
    text += "\n💡 برای انتخاب کشور دکمه زیر را بزنید:"

    if player and player["country"]:
        text += f"\n\n🏳️ کشور فعلی شما: *{COUNTRIES[player['country']]['name_fa']}*"
        kb = [[InlineKeyboardButton("📊 داشبورد من", callback_data="dashboard")]]
    else:
        kb = [[InlineKeyboardButton("🌍 انتخاب کشور", callback_data="select_country")]]

    await query.edit_message_text(text, parse_mode="Markdown",
                                  reply_markup=InlineKeyboardMarkup(kb))

# ─────────────────────────────────────────────
#  انتخاب کشور
# ─────────────────────────────────────────────
async def select_country_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    player = db.get_player(user_id)

    if player and player["country"]:
        await query.edit_message_text("❌ شما قبلاً کشور انتخاب کرده‌اید!")
        return

    taken = db.get_taken_countries()
    vip_approved = db.is_vip_approved(user_id)
    buttons = []

    for code, info in COUNTRIES.items():
        if code in taken:
            continue
        if info["vip"] and not vip_approved:
            continue
        btn_text = f"{info['flag']} {info['name_fa']} {'💯' if info['vip'] else ''}"
        buttons.append([InlineKeyboardButton(btn_text, callback_data=f"choose_{code}")])

    if not buttons:
        await query.edit_message_text("❌ هیچ کشور آزادی وجود ندارد!")
        return

    await query.edit_message_text("🌍 *کشور خود را انتخاب کنید:*",
                                  parse_mode="Markdown",
                                  reply_markup=InlineKeyboardMarkup(buttons))

async def choose_country(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    code = query.data.replace("choose_", "")

    taken = db.get_taken_countries()
    if code in taken:
        await query.edit_message_text("❌ این کشور قبلاً انتخاب شده!")
        return

    info = COUNTRIES[code]
    budget = 250_000_000 if info["vip"] else 200_000_000
    db.set_player_country(user_id, code, budget)

    text = (
        f"✅ *{info['flag']} {info['name_fa']}* انتخاب شد!\n\n"
        f"💰 بودجه اولیه: *{budget:,}$*\n\n"
        "به داشبورد خوش آمدید 🎖️"
    )
    kb = [[InlineKeyboardButton("📊 داشبورد", callback_data="dashboard")]]
    await query.edit_message_text(text, parse_mode="Markdown",
                                  reply_markup=InlineKeyboardMarkup(kb))

# ─────────────────────────────────────────────
#  داشبورد
# ─────────────────────────────────────────────
async def dashboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    player = db.get_player(user_id)

    if not player or not player["country"]:
        await query.edit_message_text("❌ ابتدا کشور انتخاب کنید!")
        return

    info = COUNTRIES[player["country"]]
    budget = player["budget"]
    daily_income = player["daily_income"]
    satisfaction = player["satisfaction"]

    text = (
        f"🏛️ *داشبورد {info['flag']} {info['name_fa']}*\n"
        f"{'─'*30}\n"
        f"💰 بودجه: *{budget:,}$*\n"
        f"📈 درآمد روزانه: *{daily_income:,}$*\n"
        f"😊 رضایت مردم: *{satisfaction}%*\n"
        f"{'─'*30}\n"
    )

    kb = [
        [InlineKeyboardButton("🏗️ خرید زیرساخت", callback_data="buy_infra"),
         InlineKeyboardButton("⚔️ خرید تجهیزات", callback_data="buy_equip")],
        [InlineKeyboardButton("👥 خرید نیرو", callback_data="buy_infantry"),
         InlineKeyboardButton("🚀 خرید موشک", callback_data="buy_missile")],
        [InlineKeyboardButton("🛡️ خرید پدافند", callback_data="buy_air_defense"),
         InlineKeyboardButton("📦 انبار من", callback_data="my_inventory")],
        [InlineKeyboardButton("🌍 لیست کشورها", callback_data="country_list"),
         InlineKeyboardButton("💸 انتقال", callback_data="transfer_menu")],
    ]
    await query.edit_message_text(text, parse_mode="Markdown",
                                  reply_markup=InlineKeyboardMarkup(kb))

# ─────────────────────────────────────────────
#  خرید زیرساخت
# ─────────────────────────────────────────────
async def buy_infra_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    player = db.get_player(user_id)

    if not player or not player["country"]:
        await query.edit_message_text("❌ ابتدا کشور انتخاب کنید!")
        return

    from data import INFRASTRUCTURE
    buttons = []
    for item_id, item in INFRASTRUCTURE.items():
        owned = db.get_infra_count(user_id, item_id)
        limit = item["limit"]
        if owned >= limit:
            btn = f"✅ {item['name']} ({owned}/{limit})"
        else:
            btn = f"🏗️ {item['name']} | {item['cost']:,}$ ({owned}/{limit})"
        buttons.append([InlineKeyboardButton(btn, callback_data=f"infra_{item_id}")])

    buttons.append([InlineKeyboardButton("🔙 برگشت", callback_data="dashboard")])
    await query.edit_message_text("🏗️ *خرید زیرساخت:*\n💰 بودجه: {:,}$".format(player["budget"]),
                                  parse_mode="Markdown",
                                  reply_markup=InlineKeyboardMarkup(buttons))

async def buy_infra_item(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    item_id = query.data.replace("infra_", "")

    from data import INFRASTRUCTURE
    item = INFRASTRUCTURE.get(item_id)
    if not item:
        await query.answer("❌ آیتم یافت نشد!", show_alert=True)
        return

    player = db.get_player(user_id)
    owned = db.get_infra_count(user_id, item_id)

    if owned >= item["limit"]:
        await query.answer("❌ به حداکثر رسیده‌اید!", show_alert=True)
        return

    if player["budget"] < item["cost"]:
        await query.answer(f"❌ بودجه کافی نیست! نیاز: {item['cost']:,}$", show_alert=True)
        return

    db.buy_infra(user_id, item_id, item["cost"], item["income"], item["satisfaction"])
    await query.answer(f"✅ {item['name']} خریداری شد!", show_alert=True)
    await buy_infra_menu(update, context)

# ─────────────────────────────────────────────
#  خرید تجهیزات نظامی
# ─────────────────────────────────────────────
async def buy_equip_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    categories = [
        ("🚩 تجهیزات زمینی", "equip_cat_ground"),
        ("✈️ تجهیزات هوایی", "equip_cat_air"),
        ("⚓ تجهیزات دریایی", "equip_cat_naval"),
    ]
    buttons = [[InlineKeyboardButton(name, callback_data=cb)] for name, cb in categories]
    buttons.append([InlineKeyboardButton("🔙 برگشت", callback_data="dashboard")])

    await query.edit_message_text("⚔️ *دسته‌بندی تجهیزات:*",
                                  parse_mode="Markdown",
                                  reply_markup=InlineKeyboardMarkup(buttons))

async def equip_category(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    cat = query.data.replace("equip_cat_", "")
    user_id = query.from_user.id
    player = db.get_player(user_id)

    items = {k: v for k, v in EQUIPMENT.items() if v["category"] == cat}
    buttons = []
    for item_id, item in items.items():
        owned = db.get_equip_count(user_id, item_id)
        buttons.append([InlineKeyboardButton(
            f"{item['name']} | {item['cost']:,}$ (دارم: {owned})",
            callback_data=f"eqbuy_{item_id}"
        )])
    buttons.append([InlineKeyboardButton("🔙 برگشت", callback_data="buy_equip")])

    await query.edit_message_text(
        f"⚔️ *لیست تجهیزات:*\n💰 بودجه: {player['budget']:,}$",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(buttons)
    )

async def buy_equip_item(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    item_id = query.data.replace("eqbuy_", "")
    item = EQUIPMENT.get(item_id)

    if not item:
        await query.answer("❌ یافت نشد!", show_alert=True)
        return

    player = db.get_player(user_id)
    if player["budget"] < item["cost"]:
        await query.answer(f"❌ بودجه کافی نیست! نیاز: {item['cost']:,}$", show_alert=True)
        return

    db.buy_equipment(user_id, item_id, item["cost"])
    await query.answer(f"✅ {item['name']} خریداری شد!", show_alert=True)

# ─────────────────────────────────────────────
#  خرید نیرو
# ─────────────────────────────────────────────
async def buy_infantry_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    player = db.get_player(user_id)

    buttons = []
    for item_id, item in INFANTRY.items():
        owned = db.get_infantry_count(user_id, item_id)
        buttons.append([InlineKeyboardButton(
            f"{item['name']} | {item['cost']:,}$/جوخه (دارم: {owned})",
            callback_data=f"infbuy_{item_id}"
        )])
    buttons.append([InlineKeyboardButton("🔙 برگشت", callback_data="dashboard")])

    await query.edit_message_text(
        f"👥 *خرید نیرو:*\n💰 بودجه: {player['budget']:,}$",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(buttons)
    )

async def buy_infantry_item(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    item_id = query.data.replace("infbuy_", "")
    item = INFANTRY.get(item_id)

    if not item:
        await query.answer("❌ یافت نشد!", show_alert=True)
        return

    player = db.get_player(user_id)
    if player["budget"] < item["cost"]:
        await query.answer(f"❌ بودجه کافی نیست! نیاز: {item['cost']:,}$", show_alert=True)
        return

    db.buy_infantry(user_id, item_id, item["cost"])
    await query.answer(f"✅ {item['name']} خریداری شد!", show_alert=True)

# ─────────────────────────────────────────────
#  خرید موشک
# ─────────────────────────────────────────────
async def buy_missile_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    player = db.get_player(user_id)

    from data import MISSILES
    buttons = []
    for item_id, item in MISSILES.items():
        owned = db.get_equip_count(user_id, item_id)
        buttons.append([InlineKeyboardButton(
            f"{item['name']} | {item['cost']:,}$ (دارم: {owned})",
            callback_data=f"msbuy_{item_id}"
        )])
    buttons.append([InlineKeyboardButton("🔙 برگشت", callback_data="dashboard")])

    await query.edit_message_text(
        f"🚀 *خرید موشک:*\n💰 بودجه: {player['budget']:,}$",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(buttons)
    )

async def buy_missile_item(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    item_id = query.data.replace("msbuy_", "")
    from data import MISSILES
    item = MISSILES.get(item_id)

    if not item:
        await query.answer("❌ یافت نشد!", show_alert=True)
        return

    player = db.get_player(user_id)
    if player["budget"] < item["cost"]:
        await query.answer(f"❌ بودجه کافی نیست!", show_alert=True)
        return

    db.buy_equipment(user_id, item_id, item["cost"])
    await query.answer(f"✅ {item['name']} خریداری شد!", show_alert=True)

# ─────────────────────────────────────────────
#  خرید پدافند
# ─────────────────────────────────────────────
async def buy_air_defense_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    player = db.get_player(user_id)

    from data import AIR_DEFENSE
    buttons = []
    for item_id, item in AIR_DEFENSE.items():
        owned = db.get_equip_count(user_id, item_id)
        buttons.append([InlineKeyboardButton(
            f"{item['name']} | {item['cost']:,}$ (دارم: {owned})",
            callback_data=f"adbuy_{item_id}"
        )])
    buttons.append([InlineKeyboardButton("🔙 برگشت", callback_data="dashboard")])

    await query.edit_message_text(
        f"🛡️ *خرید پدافند:*\n💰 بودجه: {player['budget']:,}$",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(buttons)
    )

async def buy_air_defense_item(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    item_id = query.data.replace("adbuy_", "")
    from data import AIR_DEFENSE
    item = AIR_DEFENSE.get(item_id)

    if not item:
        await query.answer("❌ یافت نشد!", show_alert=True)
        return

    player = db.get_player(user_id)
    if player["budget"] < item["cost"]:
        await query.answer(f"❌ بودجه کافی نیست!", show_alert=True)
        return

    db.buy_equipment(user_id, item_id, item["cost"])
    await query.answer(f"✅ {item['name']} خریداری شد!", show_alert=True)

# ─────────────────────────────────────────────
#  انبار من
# ─────────────────────────────────────────────
async def my_inventory(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    player = db.get_player(user_id)

    if not player or not player["country"]:
        await query.edit_message_text("❌ ابتدا کشور انتخاب کنید!")
        return

    inventory = db.get_full_inventory(user_id)
    text = f"📦 *انبار {COUNTRIES[player['country']]['name_fa']}:*\n{'─'*25}\n"

    if not inventory:
        text += "❌ انباری خالی است!\n"
    else:
        for item_name, count in inventory.items():
            text += f"• {item_name}: {count} عدد\n"

    text += f"\n💰 بودجه: {player['budget']:,}$"
    text += f"\n📈 درآمد روزانه: {player['daily_income']:,}$"
    text += f"\n😊 رضایت: {player['satisfaction']}%"

    kb = [[InlineKeyboardButton("🔙 برگشت", callback_data="dashboard")]]
    await query.edit_message_text(text, parse_mode="Markdown",
                                  reply_markup=InlineKeyboardMarkup(kb))

# ─────────────────────────────────────────────
#  انتقال پول/تجهیزات
# ─────────────────────────────────────────────
async def transfer_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    kb = [
        [InlineKeyboardButton("💸 انتقال پول", callback_data="transfer_money")],
        [InlineKeyboardButton("⚔️ انتقال تجهیزات", callback_data="transfer_equip")],
        [InlineKeyboardButton("🔙 برگشت", callback_data="dashboard")],
    ]
    await query.edit_message_text(
        "💸 *منوی انتقال:*\nبرای انتقال پول یا تجهیزات گزینه مورد نظر را انتخاب کنید:",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(kb)
    )

async def transfer_money_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    context.user_data["transfer_step"] = "money_target"
    await query.edit_message_text(
        "💸 *انتقال پول*\n\nآیدی عددی تلگرام گیرنده را بفرستید:\n(مثال: 123456789)",
        parse_mode="Markdown"
    )

async def transfer_equip_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    context.user_data["transfer_step"] = "equip_target"
    await query.edit_message_text(
        "⚔️ *انتقال تجهیزات*\n\nآیدی عددی تلگرام گیرنده را بفرستید:",
        parse_mode="Markdown"
    )

async def handle_transfer_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    step = context.user_data.get("transfer_step")

    if not step:
        return

    text = update.message.text.strip()

    if step == "money_target":
        try:
            target_id = int(text)
            target = db.get_player(target_id)
            if not target or not target["country"]:
                await update.message.reply_text("❌ این کاربر کشور ندارد!")
                context.user_data.clear()
                return
            context.user_data["transfer_target"] = target_id
            context.user_data["transfer_step"] = "money_amount"
            country_name = COUNTRIES[target["country"]]["name_fa"]
            await update.message.reply_text(f"✅ گیرنده: {country_name}\n\nمقدار پول (به دلار) را بفرستید:")
        except ValueError:
            await update.message.reply_text("❌ آیدی اشتباه است!")
            context.user_data.clear()

    elif step == "money_amount":
        try:
            amount = int(text.replace(",", ""))
            player = db.get_player(user_id)
            if amount <= 0:
                await update.message.reply_text("❌ مقدار باید بیشتر از صفر باشد!")
                return
            if player["budget"] < amount:
                await update.message.reply_text(f"❌ بودجه کافی نیست! دارید: {player['budget']:,}$")
                return
            target_id = context.user_data["transfer_target"]
            db.transfer_money(user_id, target_id, amount)
            await update.message.reply_text(f"✅ {amount:,}$ با موفقیت انتقال یافت!")
            context.user_data.clear()
        except ValueError:
            await update.message.reply_text("❌ عدد اشتباه است!")

    elif step == "equip_target":
        try:
            target_id = int(text)
            target = db.get_player(target_id)
            if not target or not target["country"]:
                await update.message.reply_text("❌ این کاربر کشور ندارد!")
                context.user_data.clear()
                return
            context.user_data["transfer_target"] = target_id
            context.user_data["transfer_step"] = "equip_name"
            await update.message.reply_text("نام تجهیز را بفرستید (مثال: panzer4):")
        except ValueError:
            await update.message.reply_text("❌ آیدی اشتباه است!")
            context.user_data.clear()

    elif step == "equip_name":
        item_id = text.lower()
        owned = db.get_equip_count(user_id, item_id)
        if owned == 0:
            await update.message.reply_text("❌ این تجهیز را ندارید!")
            context.user_data.clear()
            return
        context.user_data["transfer_equip_id"] = item_id
        context.user_data["transfer_step"] = "equip_amount"
        await update.message.reply_text(f"دارید: {owned} عدد\nچند عدد انتقال دهید؟")

    elif step == "equip_amount":
        try:
            amount = int(text)
            item_id = context.user_data["transfer_equip_id"]
            owned = db.get_equip_count(user_id, item_id)
            if amount <= 0 or amount > owned:
                await update.message.reply_text(f"❌ مقدار اشتباه! دارید: {owned}")
                return
            target_id = context.user_data["transfer_target"]
            db.transfer_equipment(user_id, target_id, item_id, amount)
            await update.message.reply_text(f"✅ {amount} عدد انتقال یافت!")
            context.user_data.clear()
        except ValueError:
            await update.message.reply_text("❌ عدد اشتباه!")

# ─────────────────────────────────────────────
#  لیست کشورها (callback)
# ─────────────────────────────────────────────
async def country_list_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await show_country_list(query)

# ─────────────────────────────────────────────
#  پنل ادمین
# ─────────────────────────────────────────────
async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in ADMIN_IDS:
        await update.message.reply_text("❌ دسترسی ندارید!")
        return

    kb = [
        [InlineKeyboardButton("✅ تایید VIP", callback_data="admin_vip"),
         InlineKeyboardButton("❌ لغو VIP", callback_data="admin_revoke_vip")],
        [InlineKeyboardButton("🎁 هدیه تجهیزات", callback_data="admin_gift_equip"),
         InlineKeyboardButton("💰 هدیه پول", callback_data="admin_gift_money")],
        [InlineKeyboardButton("🏆 مدیر جدید", callback_data="admin_add_admin"),
         InlineKeyboardButton("🔄 ریست سیزن", callback_data="admin_reset_season")],
        [InlineKeyboardButton("📋 لیست بازیکنان", callback_data="admin_players"),
         InlineKeyboardButton("🌍 VIP کشور", callback_data="admin_vip_country")],
    ]
    await update.message.reply_text("🔧 *پنل مدیریت:*",
                                    parse_mode="Markdown",
                                    reply_markup=InlineKeyboardMarkup(kb))

async def admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id

    if user_id not in ADMIN_IDS and not db.is_admin(user_id):
        await query.answer("❌ دسترسی ندارید!", show_alert=True)
        return

    await query.answer()
    action = query.data

    if action == "admin_vip":
        context.user_data["admin_step"] = "vip_approve"
        await query.edit_message_text("آیدی عددی تلگرام کاربر را برای تایید VIP بفرستید:")

    elif action == "admin_revoke_vip":
        context.user_data["admin_step"] = "vip_revoke"
        await query.edit_message_text("آیدی عددی کاربر را برای لغو VIP بفرستید:")

    elif action == "admin_gift_equip":
        context.user_data["admin_step"] = "gift_equip_target"
        await query.edit_message_text("آیدی کاربر گیرنده تجهیزات را بفرستید:")

    elif action == "admin_gift_money":
        context.user_data["admin_step"] = "gift_money_target"
        await query.edit_message_text("آیدی کاربر گیرنده پول را بفرستید:")

    elif action == "admin_add_admin":
        context.user_data["admin_step"] = "add_admin"
        await query.edit_message_text("آیدی کاربری که می‌خواهید مدیر شود را بفرستید:")

    elif action == "admin_reset_season":
        kb = [
            [InlineKeyboardButton("✅ بله، ریست کن!", callback_data="confirm_reset")],
            [InlineKeyboardButton("❌ نه", callback_data="admin_back")],
        ]
        await query.edit_message_text(
            "⚠️ *آیا مطمئنید؟*\nاین عمل همه بازیکنان را ریست می‌کند!",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(kb)
        )

    elif action == "confirm_reset":
        db.reset_season()
        await query.edit_message_text("✅ سیزن ریست شد! همه بازیکنان باید دوباره کشور انتخاب کنند.")

    elif action == "admin_players":
        players = db.get_all_players()
        text = "📋 *لیست بازیکنان:*\n\n"
        for p in players:
            country = COUNTRIES.get(p["country"], {}).get("name_fa", "ندارد") if p["country"] else "ندارد"
            text += f"👤 {p['username']} | 🌍 {country} | 💰 {p['budget']:,}$\n"
        await query.edit_message_text(text, parse_mode="Markdown")

    elif action == "admin_vip_country":
        context.user_data["admin_step"] = "vip_country_code"
        await query.edit_message_text("کد کشور را بفرستید (مثال: de، us، gb):")

    elif action == "admin_back":
        await admin_panel_callback(update, context)

async def admin_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in ADMIN_IDS and not db.is_admin(user_id):
        return

    step = context.user_data.get("admin_step")
    if not step:
        return

    text = update.message.text.strip()

    if step == "vip_approve":
        try:
            target_id = int(text)
            db.set_vip_approved(target_id, True)
            await update.message.reply_text(f"✅ کاربر {target_id} تایید VIP شد!")
        except:
            await update.message.reply_text("❌ خطا!")
        context.user_data.clear()

    elif step == "vip_revoke":
        try:
            target_id = int(text)
            db.set_vip_approved(target_id, False)
            await update.message.reply_text(f"✅ VIP کاربر {target_id} لغو شد!")
        except:
            await update.message.reply_text("❌ خطا!")
        context.user_data.clear()

    elif step == "gift_equip_target":
        try:
            target_id = int(text)
            player = db.get_player(target_id)
            if not player:
                await update.message.reply_text("❌ کاربر یافت نشد!")
                context.user_data.clear()
                return
            context.user_data["gift_target"] = target_id
            context.user_data["admin_step"] = "gift_equip_name"
            await update.message.reply_text("نام تجهیز را بفرستید (مثال: panzer4):")
        except:
            await update.message.reply_text("❌ خطا!")
            context.user_data.clear()

    elif step == "gift_equip_name":
        context.user_data["gift_equip_id"] = text.lower()
        context.user_data["admin_step"] = "gift_equip_amount"
        await update.message.reply_text("چند عدد هدیه دهید؟")

    elif step == "gift_equip_amount":
        try:
            amount = int(text)
            target_id = context.user_data["gift_target"]
            item_id = context.user_data["gift_equip_id"]
            db.admin_gift_equip(target_id, item_id, amount)
            await update.message.reply_text(f"✅ {amount} عدد {item_id} به کاربر {target_id} هدیه داده شد!")
        except:
            await update.message.reply_text("❌ خطا!")
        context.user_data.clear()

    elif step == "gift_money_target":
        try:
            target_id = int(text)
            context.user_data["gift_target"] = target_id
            context.user_data["admin_step"] = "gift_money_amount"
            await update.message.reply_text("مقدار پول را بفرستید:")
        except:
            await update.message.reply_text("❌ خطا!")
            context.user_data.clear()

    elif step == "gift_money_amount":
        try:
            amount = int(text.replace(",", ""))
            target_id = context.user_data["gift_target"]
            db.admin_gift_money(target_id, amount)
            await update.message.reply_text(f"✅ {amount:,}$ به کاربر {target_id} هدیه داده شد!")
        except:
            await update.message.reply_text("❌ خطا!")
        context.user_data.clear()

    elif step == "add_admin":
        try:
            target_id = int(text)
            db.add_admin(target_id)
            await update.message.reply_text(f"✅ کاربر {target_id} مدیر شد!")
        except:
            await update.message.reply_text("❌ خطا!")
        context.user_data.clear()

    elif step == "vip_country_code":
        code = text.lower()
        if code not in COUNTRIES:
            await update.message.reply_text("❌ کد کشور یافت نشد!")
            context.user_data.clear()
            return
        context.user_data["vip_country_code"] = code
        context.user_data["admin_step"] = "vip_country_action"
        kb = [
            [InlineKeyboardButton("✅ VIP کن", callback_data=f"set_country_vip_{code}_1")],
            [InlineKeyboardButton("❌ از VIP دربیار", callback_data=f"set_country_vip_{code}_0")],
        ]
        await update.message.reply_text(
            f"کشور: {COUNTRIES[code]['name_fa']}\nاکشن:",
            reply_markup=InlineKeyboardMarkup(kb)
        )

async def set_country_vip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    parts = query.data.split("_")
    code = parts[3]
    is_vip = int(parts[4]) == 1
    COUNTRIES[code]["vip"] = is_vip
    status = "VIP" if is_vip else "عادی"
    await query.edit_message_text(f"✅ کشور {COUNTRIES[code]['name_fa']} اکنون {status} است!")
    context.user_data.clear()

# ─────────────────────────────────────────────
#  درآمد روزانه (job)
# ─────────────────────────────────────────────
async def daily_income_job(context: ContextTypes.DEFAULT_TYPE):
    players = db.get_all_players()
    for player in players:
        if player["country"] and player["daily_income"] > 0:
            new_budget = min(player["budget"] + player["daily_income"], 500_000_000)
            db.update_budget(player["user_id"], new_budget)
            try:
                country_name = COUNTRIES[player["country"]]["name_fa"]
                await context.bot.send_message(
                    chat_id=player["user_id"],
                    text=(
                        f"📈 *درآمد روزانه دریافت شد!*\n"
                        f"🌍 {country_name}\n"
                        f"💰 +{player['daily_income']:,}$\n"
                        f"💼 بودجه جدید: {new_budget:,}$"
                    ),
                    parse_mode="Markdown"
                )
            except:
                pass

# ─────────────────────────────────────────────
#  main
# ─────────────────────────────────────────────
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    # Commands
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin_panel))

    # Callbacks
    app.add_handler(CallbackQueryHandler(joined_callback, pattern="^joined$"))
    app.add_handler(CallbackQueryHandler(select_country_menu, pattern="^select_country$"))
    app.add_handler(CallbackQueryHandler(choose_country, pattern="^choose_"))
    app.add_handler(CallbackQueryHandler(dashboard, pattern="^dashboard$"))
    app.add_handler(CallbackQueryHandler(buy_infra_menu, pattern="^buy_infra$"))
    app.add_handler(CallbackQueryHandler(buy_infra_item, pattern="^infra_"))
    app.add_handler(CallbackQueryHandler(buy_equip_menu, pattern="^buy_equip$"))
    app.add_handler(CallbackQueryHandler(equip_category, pattern="^equip_cat_"))
    app.add_handler(CallbackQueryHandler(buy_equip_item, pattern="^eqbuy_"))
    app.add_handler(CallbackQueryHandler(buy_infantry_menu, pattern="^buy_infantry$"))
    app.add_handler(CallbackQueryHandler(buy_infantry_item, pattern="^infbuy_"))
    app.add_handler(CallbackQueryHandler(buy_missile_menu, pattern="^buy_missile$"))
    app.add_handler(CallbackQueryHandler(buy_missile_item, pattern="^msbuy_"))
    app.add_handler(CallbackQueryHandler(buy_air_defense_menu, pattern="^buy_air_defense$"))
    app.add_handler(CallbackQueryHandler(buy_air_defense_item, pattern="^adbuy_"))
    app.add_handler(CallbackQueryHandler(my_inventory, pattern="^my_inventory$"))
    app.add_handler(CallbackQueryHandler(transfer_menu, pattern="^transfer_menu$"))
    app.add_handler(CallbackQueryHandler(transfer_money_start, pattern="^transfer_money$"))
    app.add_handler(CallbackQueryHandler(transfer_equip_start, pattern="^transfer_equip$"))
    app.add_handler(CallbackQueryHandler(country_list_callback, pattern="^country_list$"))
    app.add_handler(CallbackQueryHandler(admin_callback, pattern="^admin_"))
    app.add_handler(CallbackQueryHandler(admin_callback, pattern="^confirm_reset$"))
    app.add_handler(CallbackQueryHandler(set_country_vip, pattern="^set_country_vip_"))

    # Messages
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_transfer_message))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, admin_message_handler))

    # Daily income job - هر 24 ساعت
    app.job_queue.run_repeating(daily_income_job, interval=86400, first=10)

    print("🤖 بات شروع به کار کرد!")
    app.run_polling()

if __name__ == "__main__":
    main()
